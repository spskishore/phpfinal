package pkg;

import org.testng.Assert;
import org.testng.annotations.Test;

public class php_test extends j_cls {
	
  @Test
  public void f() throws InterruptedException {
	  
	  book();
	  
//	  String act_res=royal_suite;
//	  System.out.println(act_res);
//	  Assert.assertTrue(act_res.contains("Royal Suite"));
//	  System.out.println(b);
//	  Assert.assertTrue(b);
	  boolean b;
	  if(euros>100 && euros<250)
	  {
		  b=true;
	  } else {
		  b=false;
	  }
	  Assert.assertTrue(b, "Euros are <100");
  }
  
}
